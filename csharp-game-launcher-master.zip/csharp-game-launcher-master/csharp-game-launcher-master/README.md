# C# Game Launcher Tutorial
This is the source code for the launcher that we build in my [game launcher tutorial](https://youtu.be/JIjZQo03YdA) on YouTube.

**Note:** in order for this to work you will need to replace the download links in the MainWindow.xaml.cs file. If you're hosting files on Google Drive like we did in the tutorial, you can use [this](https://sites.google.com/site/gdocs2direct/) to convert sharing links into direct-download links.

[YouTube Channel](https://tomweiland.net/youtube)\
[My Blog](https://tomweiland.net/)\
[Instagram](https://tomweiland.net/instagram)\
[![ko-fi](https://www.ko-fi.com/img/githubbutton_sm.svg)](https://ko-fi.com/Y8Y21O02J)